# Extensions - Universe

Personal extensions for Shosetsu

#### Add the repo to Shosetsu using this Url:

https://jobobby04.github.io/ShosetsuExtensions/master/


### Repo Extensions
- [ArchiveOfOurOwn](https://archiveofourown.org/)
- [Hentai Foundry](https://www.hentai-foundry.com/)
- [Literotica](https://www.literotica.com/)
- [MCStories](https://mcstories.com/)
- [WuxiaBox](https://www.wuxiabox.com/)
- [WuxiaMate](https://www.wuxiamate.com/)
- [FanNovels](https://www.fannovels.com/)
- [FansMTL](https://www.fansmtl.com/)
- [WuxiaFox](https://www.wuxiafox.com/)
- [LtNovel](https://www.ltnovels.com/)
- [WuxiaOne](https://www.wuxiaone.com/)